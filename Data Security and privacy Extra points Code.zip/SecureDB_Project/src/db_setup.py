import sqlite3
import random
import string
from pyope.ope import OPE, ValueRange

# Initialize OPE cipher with a secret key
ope_cipher = OPE(b'secret_key', in_range=ValueRange(0, 20000), out_range=ValueRange(0, 20000))

# Function to generate random string
def random_string(length=10):
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(length))

# Connect to SQLite database; it will be created if it doesn't exist
conn = sqlite3.connect('secure_db.sqlite')
cursor = conn.cursor()

# Create a table
cursor.execute('''
CREATE TABLE IF NOT EXISTS healthcare_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    gender BOOLEAN NOT NULL,
    age INTEGER NOT NULL,
    weight REAL NOT NULL,
    height REAL NOT NULL,
    health_history TEXT NOT NULL
);
''')

# Commit the table creation
conn.commit()

# Insert 100 random data items
for _ in range(100):
    first_name = random_string()
    last_name = random_string()
    gender = bool(random.getrandbits(1))
    age = random.randint(1, 99)
    weight = round(random.uniform(30.0, 100.0), 2)
    scaled_weight = int(weight * 100)  # Scale the weight
    encrypted_weight = ope_cipher.encrypt(scaled_weight)
    height = round(random.uniform(1.0, 2.0), 2)
    health_history = random_string(20)

    cursor.execute("INSERT INTO healthcare_info (first_name, last_name, gender, age, weight, height, health_history) VALUES (?, ?, ?, ?, ?, ?, ?)",
                   (first_name, last_name, gender, age, encrypted_weight, height, health_history))

# Commit the insertion of data
conn.commit()

# Close the database connection
conn.close()
