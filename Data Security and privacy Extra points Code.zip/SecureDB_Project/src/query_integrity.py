import hashlib
import json

# Function to create a hash for a data item
def create_data_hash(data_item):
    data_str = json.dumps(data_item, sort_keys=True)
    return hashlib.sha256(data_str.encode()).hexdigest()

# Function to verify single data item integrity
def verify_data_integrity(data_item, data_hash):
    return create_data_hash(data_item) == data_hash

# Function to verify query completeness
def verify_query_completeness(received_hashes, expected_hashes):
    return set(received_hashes) == set(expected_hashes)
