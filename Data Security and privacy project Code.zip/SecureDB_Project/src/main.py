import sqlite3
from db_setup import random_string  # import other functions as needed
from authentication import add_user, hash_password, authenticate
from access_control import add_user_to_group, get_accessible_fields, get_user_group_by_id
from data_confidentiality import generate_key, encrypt_data, decrypt_data
from query_integrity import create_data_hash, verify_data_integrity
import tkinter as tk
from tkinter import simpledialog
from pyope.ope import OPE, ValueRange

# Initialize OPE cipher with a secret key
ope_cipher = OPE(b'secret_key', in_range=ValueRange(0, 20000), out_range=ValueRange(0, 20000))

def query_data(username, accessible_fields):
    # Query data from database based on the accessible fields for the user.
    print(f"Querying data for {username} with fields: {accessible_fields}")


def add_new_data(username, group):
    if group == 'H':
        print("Adding new data to the database.")
    else:
        print("Permission denied.")


# def display_user_data():
#     user_id = simpledialog.askstring("Query Data", "Enter User ID:")
#     if user_id:
#         group = get_user_group_by_id(user_id)
#         if group:
#             accessible_fields = get_accessible_fields(group)
#             # Assuming you have a function to fetch and display data based on accessible fields
#             data = fetch_and_display_data(user_id, accessible_fields)
#             tk.messagebox.showinfo("Data", str(data))
#         else:
#             tk.messagebox.showerror("Error", "No group found for this ID")
#     else:
#         tk.messagebox.showerror("Error", "Invalid ID")


def fetch_and_display_data(user_id, accessible_fields):
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()

    if not accessible_fields:
        tk.messagebox.showerror(
            "Error", "No accessible fields provided for this user group.")
        return

    fields_str = ', '.join(accessible_fields)
    query = f"SELECT {fields_str} FROM healthcare_info WHERE id = ?"

    try:
        cursor.execute(query, (user_id,))
        data = cursor.fetchone()

        if data:
            # Decrypt weight if it's in the accessible fields
            if 'weight' in accessible_fields:
                index = accessible_fields.index('weight')
                decrypted_weight = ope_cipher.decrypt(int(data[index]))
                unscaled_weight = decrypted_weight / 100.0  # Reverse the scaling
                data = list(data)
                data[index] = unscaled_weight

                labeled_data = "\n".join(f"{field}: {value}" for field, value in zip(accessible_fields, data))
                tk.messagebox.showinfo("Data", labeled_data)
        else:
            tk.messagebox.showerror("Error", "No data found for this ID")

    except sqlite3.Error as e:
        tk.messagebox.showerror("Error", f"An error occurred: {e}")
    finally:
        conn.close()


def display_user_data():
    user_id = simpledialog.askstring("Query Data", "Enter User ID:")
    if user_id:
        username = simpledialog.askstring("Query Data", "Enter Username:")
        if username:
            accessible_fields = get_accessible_fields(username)
            if accessible_fields:
                data = fetch_and_display_data(user_id, accessible_fields)
                if data:
                    tk.messagebox.showinfo("Data", str(data))
                else:
                    tk.messagebox.showerror(
                        "Error", "No data found for this ID")
            else:
                tk.messagebox.showerror(
                    "Error", "User does not have access to any fields")
        else:
            tk.messagebox.showerror("Error", "Invalid Username")
    else:
        tk.messagebox.showerror("Error", "Invalid ID")


def sign_up_ui():
    username = simpledialog.askstring("Sign Up", "Enter Username:")
    password = simpledialog.askstring("Sign Up", "Enter Password:", show='*')
    group = simpledialog.askstring("Sign Up", "Enter Group (H or R):")

    if group not in ['H', 'R']:
        tk.messagebox.showerror("Sign Up", "Invalid group. Please enter 'H' or 'R'")
        return

    if add_user(username, password, group):
        tk.messagebox.showinfo("Sign Up", "User created successfully")
    else:
        tk.messagebox.showerror("Sign Up", "This username already exists or an error occurred.")



def log_in_ui():
    def attempt_login():
        user_id = authenticate(username_entry.get(), password_entry.get())
        if user_id is not None:
            on_login_success(user_id)
            tk.messagebox.showinfo("Login", "Login Successful")
            login_window.destroy()
        else:
            tk.messagebox.showerror("Login", "Login Failed")

    login_window = tk.Toplevel()
    login_window.title("Login")

    tk.Label(login_window, text="Username:").pack()
    username_entry = tk.Entry(login_window)
    username_entry.pack()

    tk.Label(login_window, text="Password:").pack()
    password_entry = tk.Entry(login_window, show='*')
    password_entry.pack()

    tk.Button(login_window, text="Login", command=attempt_login).pack()



def on_login_success(user_id):
    global root
    group = get_user_group_by_id(user_id)
    if group == 'H':
        tk.Button(root, text="Add Data Item", command=add_data_item_ui).pack()
        tk.Button(root, text="Delete Data Item", command=delete_data_item_ui).pack()

def main_ui():
    global root
    root = tk.Tk()
    root.title("SecureDB Project")

    tk.Button(root, text="Sign Up", command=sign_up_ui).pack()
    tk.Button(root, text="Login", command=log_in_ui).pack()
    tk.Button(root, text="Display User Data", command=display_user_data).pack()

    root.mainloop()



def add_data_item_ui():
    def submit():
        # Data extraction from entry fields
        first_name = entry_first_name.get()
        last_name = entry_last_name.get()
        gender = entry_gender.get()
        age = entry_age.get()
        weight = entry_weight.get()
        # Encrypt the weight before inserting
        try:
            encrypted_weight = ope_cipher.encrypt(int(float(weight)))
        except ValueError:
            tk.messagebox.showerror("Error", "Invalid weight. Please enter a numeric value.")
            return

        height = entry_height.get()
        health_history = entry_health_history.get()

        # Insert data into the database
        conn = sqlite3.connect('secure_db.sqlite')
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO healthcare_info (first_name, last_name, gender, age, weight, height, health_history) VALUES (?, ?, ?, ?, ?, ?, ?)",
                           (first_name, last_name, gender, age, encrypted_weight, height, health_history))
            conn.commit()
            tk.messagebox.showinfo("Success", "Data item added successfully")
        except sqlite3.Error as e:
            tk.messagebox.showerror("Error", f"An error occurred: {e}")
        finally:
            conn.close()
            add_window.destroy()

    add_window = tk.Toplevel()
    add_window.title("Add Data Item")

    # Create and place entry fields for each data attribute
    tk.Label(add_window, text="First Name").grid(row=0, column=0)
    entry_first_name = tk.Entry(add_window)
    entry_first_name.grid(row=0, column=1)

    tk.Label(add_window, text="Last Name").grid(row=1, column=0)
    entry_last_name = tk.Entry(add_window)
    entry_last_name.grid(row=1, column=1)

    tk.Label(add_window, text="Gender (0 for Female, 1 for Male)").grid(
        row=2, column=0)
    entry_gender = tk.Entry(add_window)
    entry_gender.grid(row=2, column=1)

    tk.Label(add_window, text="Age").grid(row=3, column=0)
    entry_age = tk.Entry(add_window)
    entry_age.grid(row=3, column=1)

    tk.Label(add_window, text="Weight").grid(row=4, column=0)
    entry_weight = tk.Entry(add_window)
    entry_weight.grid(row=4, column=1)

    tk.Label(add_window, text="Height").grid(row=5, column=0)
    entry_height = tk.Entry(add_window)
    entry_height.grid(row=5, column=1)

    tk.Label(add_window, text="Health History").grid(row=6, column=0)
    entry_health_history = tk.Entry(add_window)
    entry_health_history.grid(row=6, column=1)

    tk.Button(add_window, text="Submit", command=submit).grid(
        row=8, columnspan=2)


def delete_data_item_ui():
    def delete():
        input_ids = entry_id.get()
        # Split the input string by commas and strip whitespace
        item_ids = [id.strip() for id in input_ids.split(',') if id.strip().isdigit()]

        if not item_ids:
            tk.messagebox.showerror("Error", "Invalid input. Please enter numeric IDs separated by commas.")
            return

        conn = sqlite3.connect('secure_db.sqlite')
        cursor = conn.cursor()
        try:
            # Deleting multiple records using a single query
            query = f"DELETE FROM healthcare_info WHERE id IN ({','.join('?' * len(item_ids))})"
            cursor.execute(query, item_ids)
            deleted_count = cursor.rowcount
            conn.commit()
            tk.messagebox.showinfo("Success", f"{deleted_count} data item(s) deleted")
        except sqlite3.Error as e:
            tk.messagebox.showerror("Error", f"An error occurred: {e}")
        finally:
            conn.close()
            delete_window.destroy()

    delete_window = tk.Toplevel()
    delete_window.title("Delete Data Item")

    tk.Label(delete_window, text="Enter IDs of Data Items to Delete (separated by commas)").grid(row=0, column=0)
    entry_id = tk.Entry(delete_window)
    entry_id.grid(row=0, column=1)

    tk.Button(delete_window, text="Delete", command=delete).grid(row=1, columnspan=2)


if __name__ == "__main__":
    # main()
    main_ui()
