import sqlite3

# Function to add user to a specific group
def add_user_to_group(username, group):
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()
    cursor.execute("INSERT OR IGNORE INTO user_groups (username, user_group) VALUES (?, ?)", (username, group))
    conn.commit()
    conn.close()

# Function to get user group by id
def get_user_group_by_id(user_id):
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT user_group FROM user_groups WHERE id = ?", (user_id,))
    result = cursor.fetchone()
    conn.close()

    if result:
        return result[0]
    else:
        return None

# Function to get accessible fields based on the user group
def get_accessible_fields(username):
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT user_group FROM user_groups WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()

    if result:
        group = result[0]
        if group == 'H':
            return ['first_name', 'last_name', 'gender', 'age', 'weight', 'height', 'health_history']
        elif group == 'R':
            return ['gender', 'age', 'weight', 'height', 'health_history']
    else:
        return []

# Create a user_groups table for this example
conn = sqlite3.connect('secure_db.sqlite')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS user_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    user_group TEXT NOT NULL
);
''')
conn.commit()
conn.close()
