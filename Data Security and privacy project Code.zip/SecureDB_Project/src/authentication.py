import sqlite3
import hashlib

# Function to hash a password
def hash_password(password):
    sha256 = hashlib.sha256()
    sha256.update(password.encode('utf-8'))
    return sha256.hexdigest()

# Function to add a new user
def add_user(username, password, group):
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()

    # Check if the username already exists
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        conn.close()
        return False  # Username already exists

    hashed_password = hash_password(password)
    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
        add_user_to_group(username, group)  # Add the user to the specified group
    except sqlite3.Error as e:
        print(f"An error occurred: {str(e)}")
        return False
    finally:
        conn.close()
        return True



def add_user_to_group(username, group):
    # Connect to the SQLite database
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()

    # Insert the user into the user_groups table with the specified group
    try:
        cursor.execute("INSERT INTO user_groups (username, user_group) VALUES (?, ?)", (username, group))
        conn.commit()
    except sqlite3.IntegrityError:
        print(f"User {username} already exists in the group.")
    except sqlite3.Error as e:
        print(f"An error occurred: {str(e)}")
    finally:
        conn.close()

# Function to authenticate a user
def authenticate(username, password):
    conn = sqlite3.connect('secure_db.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()

    if result:
        stored_password = result[0]
        return stored_password == hash_password(password)
    else:
        return False

# Create a users table for this example
conn = sqlite3.connect('secure_db.sqlite')
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
);
''')
conn.commit()
conn.close()
