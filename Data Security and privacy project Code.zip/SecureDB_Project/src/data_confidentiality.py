from cryptography.fernet import Fernet

# Function to generate encryption key
def generate_key():
    return Fernet.generate_key()

# Function to encrypt sensitive data
def encrypt_data(data, key, field):
    if field in ['age', 'gender']:
        f = Fernet(key)
        return f.encrypt(data.encode()).decode()
    return data


# Function to decrypt sensitive data
def decrypt_data(data, key):
    f = Fernet(key)
    return f.decrypt(data.encode()).decode()
